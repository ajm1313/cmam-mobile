# CMAM Tracker — Fresh Deployment to Stormerhost

**Server**: nutri.pharn.org  
**Hosting**: Stormerhost (cPanel shared hosting, no SSH)  
**Project path on server**: `/home/pharnorg/public_html/nutri.pharn.org/`

---

## Files in This Package

| File | Upload to | Purpose |
|------|-----------|---------|
| `passenger_wsgi.py` | `public_html/nutri.pharn.org/` | Starts the Django app via Passenger |
| `.htaccess` | `public_html/nutri.pharn.org/` | Apache/Passenger config, HTTPS, security |
| `.env.production` | Rename to `.env` on server | Database credentials & Django settings |
| `setup.sh` | `public_html/nutri.pharn.org/` | One-time install script (run via Cron) |

---

## Step 1 — Prepare the Database (5 min)

1. **cPanel → MySQL Databases**
2. If the database `pharnorg_cmam` already exists and you want a fresh start:
   - Go to **cPanel → phpMyAdmin**
   - Select `pharnorg_cmam`
   - Click **Operations** tab → **Drop the database**
3. Create the database:
   - Database name: `pharnorg_cmam`
4. Create the user (if not already created):
   - Username: `pharnorg_cmamuser`
   - Password: `AQeeiaN@13`
5. Add user to database:
   - Select `pharnorg_cmamuser` → `pharnorg_cmam`
   - Grant **ALL PRIVILEGES**
   - Click **Make Changes**

---

## Step 2 — Upload Files (10 min)

### 2.1 Upload the deployment config files

1. **cPanel → File Manager** → Navigate to `public_html/nutri.pharn.org/`
2. Click **Upload** and upload these files from `C:\wamp64\www\cmam\deploy\`:
   - `passenger_wsgi.py` (overwrite the old one)
   - `.htaccess` (overwrite the old one)
   - `setup.sh`
3. Upload `.env.production` then **rename it to `.env`** (overwrite the old one)

### 2.2 Verify files exist

After uploading, confirm these files are in `public_html/nutri.pharn.org/`:

```
✓ passenger_wsgi.py
✓ .htaccess
✓ .env
✓ setup.sh
✓ manage.py          (should already be there)
✓ requirements.txt   (should already be there)
✓ apps/              (should already be there)
✓ config/            (should already be there)
✓ templates/         (should already be there)
```

---

## Step 3 — Create Python App in cPanel (5 min)

### 3.1 Clean up old virtual environments

1. **File Manager** → Navigate to `/home/pharnorg/virtualenv/`
2. **Delete everything** inside this folder (old virtual envs)

### 3.2 Create the application

1. **cPanel → Setup Python App** → **CREATE APPLICATION**
2. Fill in:

```
Python version:          3.12.13 (recommended)
Application root:        public_html/nutri.pharn.org
Application URL:         nutri.pharn.org
Application startup file: passenger_wsgi.py
Application Entry point: application
```

> **IMPORTANT**: The Application root must be `public_html/nutri.pharn.org`  
> (NOT just `nutri.pharn.org` — include the `public_html/` prefix!)

3. Click **CREATE**

### 3.3 After creation — copy the virtualenv path

cPanel will show something like:

```
To enter to virtual environment, run:
source /home/pharnorg/virtualenv/public_html_nutri.pharn.org/3.12/bin/activate
```

**Copy that entire line.** You need it for Step 4.

---

## Step 4 — Install Dependencies & Run Setup (10 min)

Since there is no SSH terminal, we use **cPanel Cron Jobs** to run the setup script.

### 4.1 Update setup.sh with correct virtualenv path

1. **File Manager** → Open `public_html/nutri.pharn.org/setup.sh`
2. Right-click → **Edit**
3. Find line 10 (the `source` line) and replace it with the **exact activation command** cPanel showed you in Step 3.3
4. **Save**

### 4.2 Set file permissions

1. Right-click `setup.sh` → **Change Permissions**
2. Set to **755** (check all Execute boxes)
3. Click **Save**

### 4.3 Run setup via Cron Jobs

1. **cPanel → Cron Jobs**
2. Under "Add New Cron Job":
   - Common Settings: select **Once Per Minute** (we just need it to run once)
   - Command: `/home/pharnorg/public_html/nutri.pharn.org/setup.sh >> /home/pharnorg/setup_log.txt 2>&1`
3. Click **Add New Cron Job**
4. **Wait 1–2 minutes** for it to run

### 4.4 Check the log

1. **File Manager** → Navigate to `/home/pharnorg/`
2. Find `setup_log.txt`
3. Right-click → **View** or **Edit**
4. You should see:
   ```
   === Installing dependencies ===
   (pip output...)
   === Running database migrations ===
   (migration output...)
   === Collecting static files ===
   (static files output...)
   === Creating superuser ===
   Superuser created: admin
   === Setup complete! ===
   ```

### 4.5 Delete the cron job

1. **cPanel → Cron Jobs**
2. **Delete** the cron job you just created (it was one-time only)

---

## Step 5 — Test the Application (5 min)

### 5.1 Restart the app

1. **cPanel → Setup Python App**
2. Find your app in the list
3. Click the **Restart** button (circular arrow icon)

### 5.2 Open the website

1. Visit: **https://nutri.pharn.org**
2. You should see the login page

### 5.3 Log in

```
Username: admin
Password: Admin@Nutri2026!
```

(Or whatever you set in `.env` as `ADMIN_PASSWORD`)

### 5.4 Verify functionality

- [ ] Login page loads
- [ ] Can log in as admin
- [ ] Dashboard shows
- [ ] Can navigate to Cases, Reports
- [ ] Admin panel works: https://nutri.pharn.org/admin/

---

## Step 6 — Post-Setup Security (5 min)

1. **Delete `setup.sh`** from the server (it contains sensitive info)
2. **Delete `setup_log.txt`** from `/home/pharnorg/`
3. **Change your admin password** via the admin panel
4. **Generate a proper SECRET_KEY**:
   - Visit https://djecrety.ir/
   - Copy the key
   - Edit `.env` → replace the `SECRET_KEY` value
   - Restart the app

---

## Troubleshooting

### "No such application" error when creating Python app
- Make sure Application root is: **`public_html/nutri.pharn.org`** (with `public_html/` prefix)
- Delete all folders in `/home/pharnorg/virtualenv/` first
- Refresh the page and try again

### "502 Bad Gateway" or blank page
- Check `setup_log.txt` for errors
- Most common: pip install failed → re-run the cron job
- Check `.env` file has correct database credentials

### "Internal Server Error"
- Visit the URL — the error page will show debug info (Python version, sys.path, etc.)
- Usually means Django can't start: missing package or wrong DB credentials
- Check `setup_log.txt` for migration errors

### Static files not loading (page looks unstyled)
- Re-run: `python manage.py collectstatic --noinput` (add to cron job)
- Check that `staticfiles/` folder exists and has files

### Can't log in
- Verify superuser was created (check `setup_log.txt`)
- Try resetting via cron: `python manage.py changepassword admin`

---

## Server Details Reference

| Item | Value |
|------|-------|
| Domain | nutri.pharn.org |
| cPanel user | pharnorg |
| Home directory | /home/pharnorg |
| App directory | /home/pharnorg/public_html/nutri.pharn.org |
| Database | pharnorg_cmam |
| DB User | pharnorg_cmamuser |
| DB Password | AQeeiaN@13 |
| Python | 3.12.13 |
| Admin user | admin |
| Admin password | Admin@Nutri2026! (change after setup!) |
